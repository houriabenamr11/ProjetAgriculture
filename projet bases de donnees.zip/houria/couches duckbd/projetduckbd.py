import duckdb
import numpy
# Ouvrir ou créer la base
con = duckdb.connect("projet.duckdb")

# Installer et charger le module spatial
con.execute("INSTALL spatial;")
con.execute("LOAD spatial;")

# Vérifier que tout fonctionne
print(con.execute("SELECT * FROM duckdb_extensions()").fetchdf())

con.close()
